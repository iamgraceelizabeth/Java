import java.util.Scanner;

public class PlayerRoster {
   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in);
      
      final int ARRAY_LENGTH = 5;
      int[] jerseyNums = {0, 0, 0, 0, 0};
      int[] playerRatings = {0, 0, 0, 0, 0};
      int i;
      String getOption = " ";
      
      //populate arrays
      for (i = 0; i < ARRAY_LENGTH; ++i) {
         System.out.println("Enter player " + (i + 1) + "'s jersey number:");
         jerseyNums[i] = scnr.nextInt(); 
         
         System.out.println("Enter player " + (i + 1) + "'s rating:");
         playerRatings[i] = scnr.nextInt();
         
         System.out.println("");
      }
      
      //display roster
      System.out.println("ROSTER");
      for (i = 0; i < ARRAY_LENGTH; ++i) {
         System.out.printf("Player %d -- Jersey number: %d, Rating: %d\n", (i + 1), jerseyNums[i], playerRatings[i]);
      }
      
      //get user choice
      do {
         //display menu
         System.out.println("");
         System.out.println("MENU");
         System.out.printf("u - Update player rating\na - Output players above a rating\nr - Replace player\no - Output roster\nq - Quit\n");
         System.out.println("");
      
         System.out.println("Choose an option:");
         getOption = scnr.next();
      
         //configure options
         //output roster
         if (getOption.equals("o")) {
            System.out.println("ROSTER");
            for (i = 0; i < ARRAY_LENGTH; ++i) {
               System.out.printf("Player %d -- Jersey number: %d, Rating: %d\n", (i + 1), jerseyNums[i], playerRatings[i]);
            }
         } 
         else if (getOption.equals("u")) {  
            //update player rating   
            System.out.println("Enter a jersey number:");
            int jn = scnr.nextInt();
            
            for (i = 0; i < ARRAY_LENGTH; ++i) {
               if (jerseyNums[i] == jn) {
                  System.out.println("Enter a new rating for player:");
                     playerRatings[i] = scnr.nextInt();
               }
            }
         }
         else if (getOption.equals("a")) {
            //output players above a rating  
            System.out.println("Enter a rating:");
            int baseRate = scnr.nextInt();
            System.out.println("ABOVE " + baseRate);
               for (i = 0; i < ARRAY_LENGTH; ++i) {
                  if (playerRatings[i] > baseRate) {
                     System.out.printf("Player %d -- Jersey number: %d, Rating: %d\n", (i + 1) , jerseyNums[i], playerRatings[i]);
                  }
               }  
         }
         else if (getOption.equals("r")) {
            //replace player
            System.out.println("Enter a jersey number:");
            int jn = scnr.nextInt();
            for (i = 0; i < ARRAY_LENGTH; ++i) {
               if (jerseyNums[i] == jn) {
                  System.out.println("Enter a new jersey number:");
                  int newJn = scnr.nextInt();
                  System.out.println("Enter a rating for the new player:");
                  int newRating = scnr.nextInt();
                  jerseyNums[i] = newJn;
                  playerRatings[i] = newRating;
               }
               
            }
         }
         
      }while (!getOption.equals("q"));
   }
      
}
